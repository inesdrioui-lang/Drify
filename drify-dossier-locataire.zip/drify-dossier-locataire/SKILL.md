---
name: drify-dossier-locataire
description: >
  Expert en génération et amélioration du dossier de location Drify, inspiré de DossierFacile.
  Utilise ce skill dès que l'utilisateur parle du dossier locataire, de la génération PDF,
  des pièces justificatives, du template de dossier, de la page de couverture, du sommaire,
  du filigrane, du score de solvabilité, ou de tout ce qui touche à la présentation et la
  structure du dossier de location Drify.
  Utilise aussi ce skill pour : améliorer l'affichage des informations locataire, corriger
  les titres de pièces, ajouter le mot du locataire, structurer les sections, calculer le
  taux d'effort, ou comparer le rendu Drify avec DossierFacile.
  Ce skill est la référence absolue pour tout ce qui concerne la qualité et la conformité
  du dossier locataire généré par Drify.
---

# Drify — Dossier Locataire Expert

Ce skill guide la création, l'amélioration et la génération du dossier de location Drify,
en s'inspirant des meilleures pratiques de DossierFacile tout en affirmant l'identité propre
de Drify.

---

## Architecture du dossier idéal

### Page 1 — Couverture

Éléments **obligatoires** dans cet ordre exact :
1. **Logo Drify** + baseline "La plateforme de location de confiance"
2. **Titre** : "Le dossier de location de [PRÉNOM NOM]"
3. **Tableau "En un coup d'œil"** — 3 colonnes :
   | Type de dossier | Revenus mensuels nets | Garant(s) |
   | Seul / En couple / Colocation | Montant en € | Aucun / Physique / Organisme |
4. **Sommaire des pièces** avec renvoi de page explicite :
   - Lister chaque pièce avec son numéro de page (p.X)
   - Regrouper par catégorie (Identité / Logement actuel / Activité pro / Ressources / Garant)
5. **Loyer maximum recommandé** = revenus nets / 3 (taux d'effort 33%)
6. **Pied de page** : mention légale + référence DRF + date de génération

### Page 2 — Profil & mot du locataire

Éléments **obligatoires** :
1. **Informations de profil détaillées** :
   - Situation professionnelle (intitulé exact : CDI, fonctionnaire, gérant, étudiant...)
   - Employeur / Établissement
   - Ancienneté si disponible
   - Situation personnelle (seul, en couple, avec enfants)
2. **Le mot du locataire** — champ texte libre saisi par le locataire
   - Afficher même si court ("je suis soigneux et...")
   - Si vide : afficher un encadré grisé "Le locataire n'a pas rédigé de message"
3. **Score de solvabilité Drify** :
   - Taux d'effort : loyer cible / revenus nets × 100
   - Indicateur visuel : Excellent (<25%) / Bon (25-33%) / Limite (33-40%) / Insuffisant (>40%)
   - Explication textuelle de la méthodologie

### Pages 3 à N — Pièces justificatives

Chaque pièce suit cette structure :

**En-tête de section** (page titre si nouvelle catégorie) :
```
[NOM PRÉNOM]
[Catégorie de document — titre humain]
```

**Titre humain obligatoire** par type de pièce :
- CNI / Passeport → "La pièce d'identité de [Prénom]"
- Fiche de paie → "Le bulletin de salaire n°[X] de [Prénom] — [Mois Année]"
- Avis d'imposition → "L'avis d'imposition [Année] de [Prénom]"
- Contrat de travail → "Le contrat de travail de [Prénom]"
- Bail en cours → "Le justificatif de logement actuel de [Prénom]"
- Quittances de loyer → "La quittance de loyer n°[X] de [Prénom]"
- Extrait Kbis → "L'extrait Kbis de [Prénom]"
- Relevé bancaire → "Le relevé bancaire de [Prénom]"
- Justificatif domicile → "Le justificatif de domicile de [Prénom]"
- RIB → NE PAS inclure dans le dossier (données bancaires sensibles)

**Jamais** : "image.png", "document.pdf", noms de fichiers bruts.
**Règle** : si le type de pièce n'est pas reconnu, utiliser "Le document de [Prénom]" + demander correction.

### Dernières pages — Garant(s)

Si garant physique :
- Même structure que les pages locataire
- En-tête : "Les pièces justificatives de [Nom garant], garant de [Nom locataire]"

Si garant organisme (Visale, Action Logement) :
- Page titre : "L'attestation de garantie de [Prénom]"
- Inclure le document d'attestation en pleine page

---

## Filigrane de protection

À appliquer sur **chaque page de pièce justificative** (pas sur la couverture ni le sommaire) :

**Texte** : "DOCUMENT DRIFY — USAGE LOCATION IMMOBILIÈRE UNIQUEMENT"
**Style** :
- Rotation : -45 degrés
- Répétition : grille 3×4 sur la page
- Opacité : 0.08 (très discret, ne gêne pas la lecture)
- Police : sans-serif, 11px, couleur #2C2C2A
- Position : superposé au document, au-dessus de l'image

**Ne pas mettre de filigrane sur** : couverture, sommaire, page de profil, pages titre de section.

---

## Règles de qualité des données

### Revenus
- Afficher toujours en **nets mensuels**
- Si revenus = 0€ ou non renseignés : expliquer la raison textuellement
  ex : "Prénom n'a pas renseigné de revenus — rattaché au foyer fiscal de ses parents"
- Ne jamais afficher "0 €" sans explication
- Revenus variables (auto-entrepreneur, intermittent) : afficher la moyenne sur 3 mois

### Statut professionnel
- Fonctionnaire → préciser corps et grade si disponible
- CDI → préciser le poste et l'employeur
- CDD → préciser la durée restante
- Étudiant → préciser l'établissement et le niveau d'études
- Auto-entrepreneur → préciser le domaine d'activité

### Données manquantes
- Pièce manquante : l'indiquer clairement dans le sommaire avec "(manquante)"
- Ne jamais générer une page vide ou avec juste un titre
- Si image illisible ou corrompue : afficher "Document fourni — lisibilité à vérifier"

---

## Identité visuelle Drify

### Palette de couleurs
- **Primaire** : couleur principale Drify (à récupérer dans le design system Drify)
- **Fond de couverture** : blanc ou très légèrement teinté (#FAFAF8)
- **Accents** : utiliser la couleur Drify pour les en-têtes, la barre latérale gauche, les titres de section
- **Texte** : #2C2C2A (anthracite) pour le corps, #888780 pour les labels secondaires

### Typographie
- **Titres** : font principale Drify ou Inter/DM Sans, 500
- **Corps** : même font, 400, 14px
- **Labels** : 12px, uppercase, letter-spacing 0.05em

### Structure de page
- **Marge** : 40px sur tous les côtés
- **En-tête** : bande de 48px avec logo (gauche) + breadcrumb "Prénom NOM / Catégorie" (droite)
- **Barre latérale gauche** : 4px, couleur Drify, sur toute la hauteur utile de la page
- **Pied de page** : 32px, "Dossier généré par Drify · drify.fr · Réf. [CODE] · N/Total"

---

## Vérifications avant génération

Checklist à parcourir mentalement avant de valider la génération :

- [ ] Toutes les pièces ont un titre humain (aucun "image.png")
- [ ] Le sommaire liste chaque pièce avec son numéro de page
- [ ] Les revenus sont affichés avec explication si = 0€
- [ ] Le statut professionnel est détaillé (pas juste "Salarié")
- [ ] Le mot du locataire est affiché ou remplacé par un encadré vide
- [ ] Le score de solvabilité est calculé et expliqué
- [ ] Le filigrane est en place sur toutes les pièces (pas sur la couverture)
- [ ] Les garants ont leurs propres sections distinctes
- [ ] La référence DRF et la date sont dans le pied de page
- [ ] Aucune page RIB n'est incluse

---

## Référence complémentaire

Pour les détails d'implémentation technique (génération PDF, composants React/Next.js),
lire `references/implementation.md`.

Pour les règles métier détaillées sur la loi ALUR et les pièces autorisées,
lire `references/loi-alur.md`.
