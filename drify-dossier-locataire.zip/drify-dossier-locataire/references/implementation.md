# Implémentation technique — Dossier locataire Drify

## Stack technique Drify
- **Framework** : Next.js (App Router)
- **Base de données** : Supabase
- **Génération PDF** : à déterminer (voir options ci-dessous)
- **Stockage pièces** : Supabase Storage

---

## Options de génération PDF

### Option A — @react-pdf/renderer (recommandée)
Génération côté serveur en Next.js, rendu React → PDF.

```bash
npm install @react-pdf/renderer
```

**Avantages** : composants React réutilisables, styles CSS-in-JS, bon support des images.
**Inconvénients** : polices personnalisées complexes à intégrer.

```tsx
// app/api/dossier/generate/route.ts
import { renderToBuffer } from '@react-pdf/renderer';
import { DossierPDF } from '@/components/pdf/DossierPDF';

export async function POST(req: Request) {
  const data = await req.json();
  const buffer = await renderToBuffer(<DossierPDF dossier={data} />);
  
  return new Response(buffer, {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="dossier-${data.ref}.pdf"`,
    },
  });
}
```

### Option B — Puppeteer / html-pdf-node
Rendu HTML → PDF via navigateur headless. Plus fidèle au design web.

```bash
npm install puppeteer
```

**Avantages** : rendu pixel-perfect depuis le HTML existant, support total des CSS.
**Inconvénients** : plus lourd, lent sur Vercel (préférer une fonction Edge ou un service dédié).

---

## Structure des données locataire (Supabase)

```typescript
interface Dossier {
  id: string;
  ref: string; // DRF-2026-XXXXXXXX
  created_at: string;
  
  locataire: {
    prenom: string;
    nom: string;
    email: string;
    telephone?: string;
    
    // Profil professionnel
    statut: 'cdi' | 'cdd' | 'fonctionnaire' | 'independant' | 'etudiant' | 'retraite' | 'sans_emploi';
    poste?: string;
    employeur?: string;
    anciennete_mois?: number;
    
    // Situation personnelle
    situation_familiale: 'seul' | 'en_couple' | 'avec_enfants';
    
    // Revenus
    revenus_nets_mensuels: number;
    revenus_justification?: string; // si = 0
    
    // Mot du locataire
    mot_locataire?: string;
  };
  
  type_dossier: 'seul' | 'couple' | 'colocation';
  
  pieces: Piece[];
  garants: Garant[];
}

interface Piece {
  id: string;
  categorie: PieceCategorie;
  nom_original: string; // nom du fichier uploadé
  nom_affiche: string;  // titre humain calculé
  url: string;
  ordre: number;
  statut: 'fourni' | 'manquant' | 'illisible';
}

type PieceCategorie = 
  | 'identite'
  | 'domicile_actuel'
  | 'activite_professionnelle'
  | 'ressources_fiche_paie'
  | 'ressources_autre'
  | 'avis_imposition'
  | 'contrat_travail'
  | 'autre';
```

---

## Génération du titre humain d'une pièce

```typescript
function getTitreHumain(piece: Piece, locataire: { prenom: string }, index: number): string {
  const p = locataire.prenom;
  
  switch (piece.categorie) {
    case 'identite':
      return `La pièce d'identité de ${p}`;
    case 'domicile_actuel':
      return `Le justificatif de logement actuel de ${p}`;
    case 'activite_professionnelle':
      return `Le justificatif d'activité professionnelle de ${p}`;
    case 'ressources_fiche_paie':
      return `Le bulletin de salaire n°${index} de ${p}`;
    case 'avis_imposition':
      return `L'avis d'imposition de ${p}`;
    case 'contrat_travail':
      return `Le contrat de travail de ${p}`;
    case 'ressources_autre':
      return `Le justificatif de ressources de ${p}`;
    default:
      // Ne jamais retourner le nom de fichier brut
      return `Le document de ${p}`;
  }
}
```

---

## Filigrane — implémentation CSS (HTML → PDF via Puppeteer)

```css
.page-piece {
  position: relative;
}

.page-piece::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  background-image: repeating-linear-gradient(
    -45deg,
    transparent,
    transparent 80px,
    rgba(44, 44, 42, 0.04) 80px,
    rgba(44, 44, 42, 0.04) 82px
  );
  pointer-events: none;
  z-index: 10;
}

.watermark-text {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) rotate(-45deg);
  font-size: 11px;
  font-family: sans-serif;
  color: rgba(44, 44, 42, 0.08);
  white-space: nowrap;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  pointer-events: none;
  z-index: 10;
  user-select: none;
}
```

## Filigrane — implémentation @react-pdf/renderer

```tsx
import { Text, View, StyleSheet } from '@react-pdf/renderer';

const Filigrane = () => (
  <>
    {Array.from({ length: 12 }).map((_, i) => (
      <Text
        key={i}
        style={{
          position: 'absolute',
          top: `${(i % 4) * 25 + 10}%`,
          left: `${Math.floor(i / 4) * 33 + 5}%`,
          fontSize: 8,
          color: 'rgba(44, 44, 42, 0.07)',
          transform: 'rotate(-45deg)',
          fontFamily: 'Helvetica',
        }}
      >
        DOCUMENT DRIFY — USAGE LOCATION UNIQUEMENT
      </Text>
    ))}
  </>
);
```

---

## Calcul du score de solvabilité

```typescript
interface ScoreSolvabilite {
  taux_effort: number; // en %
  niveau: 'excellent' | 'bon' | 'limite' | 'insuffisant';
  label: string;
  loyer_max_recommande: number;
}

function calculerSolvabilite(revenus: number, loyer_cible?: number): ScoreSolvabilite {
  const loyer_max = Math.round(revenus / 3);
  const taux = loyer_cible ? Math.round((loyer_cible / revenus) * 100) : 33;
  
  let niveau: ScoreSolvabilite['niveau'];
  let label: string;
  
  if (taux < 25) {
    niveau = 'excellent';
    label = 'Dossier très solide — revenus confortables par rapport au loyer';
  } else if (taux <= 33) {
    niveau = 'bon';
    label = 'Dossier solide — taux d\'effort dans les normes';
  } else if (taux <= 40) {
    niveau = 'limite';
    label = 'Taux d\'effort élevé — un garant peut renforcer le dossier';
  } else {
    niveau = 'insuffisant';
    label = 'Taux d\'effort trop élevé — garant fortement recommandé';
  }
  
  return { taux_effort: taux, niveau, label, loyer_max_recommande: loyer_max };
}
```

---

## Référence DRF

Format : `DRF-[ANNÉE]-[8 caractères hex en majuscules]`
Exemple : `DRF-2026-C90A28AF`

```typescript
function genererRef(): string {
  const annee = new Date().getFullYear();
  const hex = crypto.randomUUID().replace(/-/g, '').substring(0, 8).toUpperCase();
  return `DRF-${annee}-${hex}`;
}
```
