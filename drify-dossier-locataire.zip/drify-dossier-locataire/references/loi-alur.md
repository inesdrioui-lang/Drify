# Règles métier — Loi ALUR & pièces justificatives

## Cadre légal

La loi ALUR (2014) et son décret d'application du 5 novembre 2015 fixent la liste
**exhaustive et limitative** des pièces qu'un bailleur peut demander.
Drify doit s'y conformer strictement.

---

## Pièces autorisées par catégorie

### 1. Identité (1 pièce maximum)
- Carte nationale d'identité française ou étrangère (recto/verso)
- Passeport français ou étranger (pages avec photo et état civil)
- Permis de conduire français ou étranger
- Document de séjour valide (carte de résident, titre de séjour)

**Interdit** : Demander plusieurs pièces d'identité.

### 2. Domicile actuel (au choix)
- 3 dernières quittances de loyer (ou attestation de logement gratuit)
- Dernier avis de taxe foncière (si propriétaire)
- Attestation d'hébergement signée par l'hébergeant + sa pièce d'identité + preuve de son domicile
- Facture EDF/eau/gaz/téléphone de moins de 3 mois

### 3. Activité professionnelle (selon situation)

**Salarié** :
- Contrat de travail (CDI complet, ou extrait mentionnant durée/employeur/poste/salaire)
- Si pas de contrat : attestation employeur sur papier à en-tête récente

**Fonctionnaire** :
- Arrêté de nomination (ou dernier arrêté d'avancement)

**Indépendant / Auto-entrepreneur** :
- Extrait Kbis de moins de 3 mois (ou extrait SIRENE)
- Statuts signés de la société (si gérant)
- Carte professionnelle (si profession réglementée)

**Étudiant** :
- Certificat de scolarité ou carte étudiante de l'année en cours
- Attestation de bourse si boursier

**Sans emploi** :
- Attestation Pôle Emploi ou notification CAF récente

**Retraité** :
- Titre de pension ou dernier bulletin de pension

### 4. Ressources (selon situation)

**Salarié** :
- 3 derniers bulletins de salaire

**Indépendant (2+ ans d'activité)** :
- 2 derniers bilans comptables (ou avis d'imposition)
- Déclaration de revenus professionnels (n-1 et n-2)

**Indépendant (< 2 ans d'activité)** :
- Bilan prévisionnel
- Attestation de revenus de l'expert-comptable

**Revenus de remplacement** :
- Attestation CAF (APL, AAH, RSA)
- Attestation Pôle Emploi avec montant des allocations
- Titre de pension / notification retraite

**Pas de revenus** :
- Le locataire peut expliquer sa situation par écrit
- Drify affiche la justification textuelle dans le dossier
- Un garant est alors fortement recommandé

### 5. Avis d'imposition
- Dernier avis d'imposition ou de non-imposition

**Si rattaché au foyer fiscal des parents** :
- L'indiquer explicitement dans le dossier
- Optionnel : avis d'imposition des parents

### 6. Garant physique (mêmes catégories)
- Identité
- Domicile
- Activité professionnelle
- Ressources (3 derniers bulletins)
- Avis d'imposition

### 7. Garant organisme
- Attestation Visale (Action Logement)
- Attestation GarantMe
- Attestation Cautioneo
- Attestation Unkle

---

## Pièces formellement INTERDITES

Le bailleur **ne peut pas** demander (et Drify ne doit pas les intégrer) :

- RIB / coordonnées bancaires
- Extrait de casier judiciaire
- Photo d'identité
- Dossier médical ou attestation de bonne santé
- Relevés de compte bancaire
- Attestation de bonne tenue de compte
- Attestation d'absence de crédit
- Contrat de mariage / PACS (sauf si co-locataire)
- Attestation de l'ancien propriétaire (risque de discrimination)
- Chèque de réservation

**Exception RIB** : autorisé uniquement après signature du bail, pour le prélèvement automatique du loyer.

---

## Règle des 3 bulletins de salaire

Les 3 derniers bulletins correspondent aux 3 mois civils précédant la date de génération du dossier.

- Mai 2026 → bulletins de Février, Mars, Avril 2026
- Alerter si les bulletins fournis sont trop anciens (> 4 mois)
- Alerter si les montants sont incohérents (variation > 30% sans explication)

---

## Taux d'effort — normes du marché français

| Taux d'effort | Interprétation | Action recommandée |
|---|---|---|
| < 25% | Excellent | Dossier autonome solide |
| 25 — 33% | Standard | Conforme à la norme bancaire |
| 33 — 40% | Élevé | Garant recommandé |
| > 40% | Très élevé | Garant quasi-obligatoire |

La règle du tiers (33%) est une norme professionnelle, pas une obligation légale.
Certains bailleurs acceptent 35-40% pour des CDI stables ou fonctionnaires.

---

## Cas spéciaux

### Dossier en couple / colocation
- Chaque colocataire a ses propres pièces dans des sections distinctes
- Les revenus sont **cumulés** pour le calcul du taux d'effort
- Chaque signataire du bail doit être dans le dossier

### Locataire étranger (hors UE)
- Titre de séjour valide obligatoire
- Pas d'avis d'imposition français si récent en France → accepter avis étranger traduit
- Revenus en devise étrangère → convertir en EUR au taux du jour + noter la source

### Micro-entrepreneur (auto-entrepreneur)
- Moins de 2 ans d'activité : revenus estimés, à vérifier avec 3 relevés bancaires
- Revenus variables : calculer la moyenne mensuelle sur les 12 derniers mois
- Le dernier avis d'imposition reste la référence officielle
